// GLOBAL AUTHENTICATION SYSTEM - StudySchedule Portal
// This script fixes all authentication and data storage issues

(function() {
    'use strict';

    // Global authentication state
    window.StudyAuth = {
        // Check if user is authenticated
        isLoggedIn: function() {
            const currentUser = localStorage.getItem('currentUser');
            const isLoggedIn = localStorage.getItem('isLoggedIn');
            return currentUser && isLoggedIn === 'true';
        },

        // Get current user data
        getCurrentUser: function() {
            try {
                const userData = localStorage.getItem('currentUser');
                return userData ? JSON.parse(userData) : null;
            } catch (error) {
                console.error('Error getting current user:', error);
                return null;
            }
        },

        // Update navigation for all pages
        updateNavigation: function() {
            const authNav = document.getElementById('authNav');
            if (!authNav) return;

            if (this.isLoggedIn()) {
                const user = this.getCurrentUser();
                authNav.innerHTML = `
                    <div class="dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user me-1"></i>${user.name}
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#" onclick="StudyAuth.logout()">
                                <i class="fas fa-sign-out-alt me-2"></i>Logout
                            </a></li>
                        </ul>
                    </div>
                `;
            } else {
                authNav.innerHTML = '<a class="nav-link" href="login.html">Login</a>';
            }
        },

        // Logout function
        logout: function() {
            localStorage.removeItem('currentUser');
            localStorage.removeItem('isLoggedIn');
            localStorage.removeItem('sessionExpiry');

            // Show success message
            this.showMessage('Successfully logged out!', 'success');

            // Redirect to home
            setTimeout(() => {
                window.location.href = 'index.html';
            }, 1500);
        },

        // Save user-specific data
        saveUserData: function(key, data) {
            if (!this.isLoggedIn()) return false;

            const user = this.getCurrentUser();
            const userKey = `${key}_${user.id}`;
            localStorage.setItem(userKey, JSON.stringify(data));
            return true;
        },

        // Load user-specific data
        loadUserData: function(key, defaultValue = []) {
            if (!this.isLoggedIn()) return defaultValue;

            const user = this.getCurrentUser();
            const userKey = `${key}_${user.id}`;

            try {
                const data = localStorage.getItem(userKey);
                return data ? JSON.parse(data) : defaultValue;
            } catch (error) {
                console.error('Error loading user data:', error);
                return defaultValue;
            }
        },

        // Show message alerts
        showMessage: function(message, type = 'info') {
            // Remove existing alerts
            const existingAlerts = document.querySelectorAll('.temp-alert');
            existingAlerts.forEach(alert => alert.remove());

            const alertHtml = `
                <div class="alert alert-${type} alert-dismissible fade show temp-alert position-fixed" 
                     style="top: 20px; right: 20px; z-index: 9999; max-width: 400px;" role="alert">
                    <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'danger' ? 'exclamation-triangle' : 'info-circle'} me-2"></i>
                    ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            `;
            document.body.insertAdjacentHTML('beforeend', alertHtml);

            // Auto-hide after 4 seconds
            setTimeout(() => {
                const alerts = document.querySelectorAll('.temp-alert');
                alerts.forEach(alert => {
                    if (alert.textContent.includes(message)) {
                        alert.remove();
                    }
                });
            }, 4000);
        },

        // Initialize authentication on page load
        init: function() {
            this.updateNavigation();

            // If on a protected page and not logged in, redirect to login
            const protectedPages = ['create-schedule.html', 'create-group.html', 'create-session.html'];
            const currentPage = window.location.pathname.split('/').pop();

            if (protectedPages.includes(currentPage) && !this.isLoggedIn()) {
                localStorage.setItem('redirectAfterLogin', window.location.href);
                window.location.href = 'login.html';
                return;
            }

            // If on login/register page and already logged in, redirect to dashboard
            const authPages = ['login.html', 'register.html'];
            if (authPages.includes(currentPage) && this.isLoggedIn()) {
                window.location.href = 'dashboard.html';
                return;
            }

            // Update page content based on authentication status
            this.updatePageContent();
        },

        // Update page content based on authentication
        updatePageContent: function() {
            const currentPage = window.location.pathname.split('/').pop();

            if (this.isLoggedIn()) {
                // Hide login required alerts
                const loginAlerts = document.querySelectorAll('.alert-warning');
                loginAlerts.forEach(alert => {
                    if (alert.textContent.includes('Login Required')) {
                        alert.style.display = 'none';
                    }
                });

                // Show authenticated content based on page
                switch(currentPage) {
                    case 'schedules.html':
                        this.loadSchedulePage();
                        break;
                    case 'sessions.html':
                        this.loadSessionsPage();
                        break;
                    case 'groups.html':
                        this.loadGroupsPage();
                        break;
                    case 'dashboard.html':
                        this.loadDashboardPage();
                        break;
                }
            }
        },

        // Load schedule page data
        loadSchedulePage: function() {
            const schedules = this.loadUserData('userSchedules', []);
            console.log('Loading schedules:', schedules);

            // Update statistics
            const total = schedules.length;
            const completed = schedules.filter(s => s.status === 'completed').length;
            const pending = total - completed;
            const weeklyHours = Math.round(schedules.reduce((sum, s) => sum + (s.duration || 0), 0) / 60);

            // Update stat cards if they exist
            const statCards = document.querySelectorAll('.stat-number');
            if (statCards.length >= 4) {
                statCards[0].textContent = total;
                statCards[1].textContent = completed;
                statCards[2].textContent = pending;
                statCards[3].textContent = weeklyHours + 'h';
            }

            // Display schedules
            if (schedules.length > 0) {
                this.displaySchedules(schedules);
            }
        },

        // Load sessions page data
        loadSessionsPage: function() {
            const sessions = this.loadUserData('userSchedules', []);
            console.log('Loading sessions:', sessions);

            // Update statistics
            const total = sessions.length;
            const completed = sessions.filter(s => s.status === 'completed').length;
            const upcoming = sessions.filter(s => {
                const sessionDate = new Date(s.date + ' ' + s.time);
                return sessionDate > new Date() && s.status !== 'completed';
            }).length;
            const totalHours = Math.round(sessions.reduce((sum, s) => sum + (s.duration || 0), 0) / 60);

            // Update stat cards if they exist
            const statCards = document.querySelectorAll('.stat-number');
            if (statCards.length >= 4) {
                statCards[0].textContent = total;
                statCards[1].textContent = completed;
                statCards[2].textContent = upcoming;
                statCards[3].textContent = totalHours + 'h';
            }

            // Display sessions
            if (sessions.length > 0) {
                this.displaySessions(sessions);
            }
        },

        // Load groups page data
        loadGroupsPage: function() {
            const groups = this.loadUserData('userGroups', []);
            console.log('Loading groups:', groups);

            // Display groups
            if (groups.length > 0) {
                this.displayGroups(groups);
            }
        },

        // Load dashboard page data
        loadDashboardPage: function() {
            const user = this.getCurrentUser();
            const schedules = this.loadUserData('userSchedules', []);
            const groups = this.loadUserData('userGroups', []);

            // Update welcome message
            const welcomeMsg = document.getElementById('welcomeMessage');
            const welcomeSubtext = document.getElementById('welcomeSubtext');

            if (welcomeMsg) {
                welcomeMsg.textContent = `Welcome back, ${user.name}!`;
            }
            if (welcomeSubtext) {
                welcomeSubtext.textContent = "Here's your personalized dashboard";
            }

            // Update statistics
            const totalGroups = groups.length;
            const upcomingSessions = schedules.filter(s => {
                const sessionDate = new Date(s.date + ' ' + s.time);
                return sessionDate > new Date() && s.status !== 'completed';
            }).length;
            const studyHours = Math.round(schedules.reduce((sum, s) => sum + (s.duration || 0), 0) / 60);

            // Update stat cards
            const statElements = {
                totalGroups: document.getElementById('totalGroups'),
                upcomingSessions: document.getElementById('upcomingSessions'),
                studyHours: document.getElementById('studyHours'),
                currentGPA: document.getElementById('currentGPA')
            };

            if (statElements.totalGroups) statElements.totalGroups.textContent = totalGroups;
            if (statElements.upcomingSessions) statElements.upcomingSessions.textContent = upcomingSessions;
            if (statElements.studyHours) statElements.studyHours.textContent = studyHours;
            if (statElements.currentGPA) statElements.currentGPA.textContent = (user.gpa || 0).toFixed(1);

            // Show/hide appropriate content sections
            const loginPrompt = document.getElementById('loginPrompt');
            const authenticatedContent = document.getElementById('authenticatedContent');
            const featureOverview = document.getElementById('featureOverview');

            if (loginPrompt) loginPrompt.style.display = 'none';
            if (authenticatedContent) authenticatedContent.style.display = 'block';
            if (featureOverview) featureOverview.style.display = 'none';
        },

        // Display schedules
        displaySchedules: function(schedules) {
            const container = document.querySelector('.row:last-child') || document.querySelector('main .container .row:last-child');
            if (!container) return;

            let schedulesHtml = '<div class="col-12"><h4 class="mb-4">My Study Schedules</h4></div>';
            schedulesHtml += '<div class="col-12 mb-3"><a href="create-schedule.html" class="btn btn-primary"><i class="fas fa-plus me-2"></i>Add New Schedule</a></div>';

            schedules.forEach(schedule => {
                const statusBadge = schedule.status === 'completed' ?
                    '<span class="badge bg-success">Completed</span>' :
                    '<span class="badge bg-warning">Pending</span>';

                schedulesHtml += `
                    <div class="col-md-6 col-lg-4 mb-3">
                        <div class="card h-100">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <h5 class="card-title">${schedule.subject}</h5>
                                    ${statusBadge}
                                </div>
                                <h6 class="card-subtitle mb-2 text-muted">${schedule.topic}</h6>
                                <p class="card-text">
                                    <i class="fas fa-calendar me-2"></i>${schedule.date}<br>
                                    <i class="fas fa-clock me-2"></i>${schedule.time} (${schedule.duration}min)
                                </p>
                                <button class="btn btn-sm btn-outline-danger" onclick="StudyAuth.deleteSchedule(${schedule.id})">
                                    <i class="fas fa-trash"></i> Delete
                                </button>
                            </div>
                        </div>
                    </div>
                `;
            });

            container.innerHTML = schedulesHtml;
        },

        // Display sessions (same as schedules but different view)
        displaySessions: function(sessions) {
            const container = document.querySelector('.row:last-child') || document.querySelector('main .container .row:last-child');
            if (!container) return;

            let sessionsHtml = '<div class="col-12"><h4 class="mb-4">My Study Sessions</h4></div>';
            sessionsHtml += '<div class="col-12 mb-3"><a href="create-schedule.html" class="btn btn-primary"><i class="fas fa-plus me-2"></i>Create New Session</a></div>';

            sessions.forEach(session => {
                const statusClass = session.status === 'completed' ? 'success' : 'warning';
                const statusText = session.status === 'completed' ? 'Completed' : 'Pending';

                sessionsHtml += `
                    <div class="col-md-6 col-lg-4 mb-3">
                        <div class="card h-100">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <h5 class="card-title">${session.subject}</h5>
                                    <span class="badge bg-${statusClass}">${statusText}</span>
                                </div>
                                <h6 class="card-subtitle mb-2 text-muted">${session.topic}</h6>
                                <p class="card-text">
                                    <i class="fas fa-calendar me-2"></i>${session.date}<br>
                                    <i class="fas fa-clock me-2"></i>${session.time} (${session.duration}min)
                                </p>
                                <div class="d-flex justify-content-between">
                                    ${session.status !== 'completed' ? `
                                    <button class="btn btn-sm btn-success" onclick="StudyAuth.markCompleted(${session.id})">
                                        <i class="fas fa-check"></i> Complete
                                    </button>` : '<span></span>'}
                                    <button class="btn btn-sm btn-outline-danger" onclick="StudyAuth.deleteSchedule(${session.id})">
                                        <i class="fas fa-trash"></i> Delete
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
            });

            container.innerHTML = sessionsHtml;
        },

        // Display groups
        displayGroups: function(groups) {
            const container = document.querySelector('.row:last-child') || document.querySelector('main .container .row:last-child');
            if (!container) return;

            let groupsHtml = '<div class="col-12"><h4 class="mb-4">My Study Groups</h4></div>';
            groupsHtml += '<div class="col-12 mb-3"><a href="create-group.html" class="btn btn-primary"><i class="fas fa-plus me-2"></i>Create New Group</a></div>';

            groups.forEach(group => {
                groupsHtml += `
                    <div class="col-md-6 col-lg-4 mb-3">
                        <div class="card h-100">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <h5 class="card-title">${group.name}</h5>
                                    <span class="badge bg-primary">${group.subject}</span>
                                </div>
                                <p class="card-text">${group.description || 'No description'}</p>
                                <button class="btn btn-sm btn-outline-danger" onclick="StudyAuth.leaveGroup(${group.id})">
                                    <i class="fas fa-sign-out-alt"></i> Leave
                                </button>
                            </div>
                        </div>
                    </div>
                `;
            });

            container.innerHTML = groupsHtml;
        },

        // Delete schedule
        deleteSchedule: function(scheduleId) {
            if (confirm('Are you sure you want to delete this schedule?')) {
                let schedules = this.loadUserData('userSchedules', []);
                schedules = schedules.filter(s => s.id !== scheduleId);
                this.saveUserData('userSchedules', schedules);
                this.showMessage('Schedule deleted successfully!', 'success');
                // Reload page to refresh content
                setTimeout(() => window.location.reload(), 1000);
            }
        },

        // Mark session as completed
        markCompleted: function(sessionId) {
            if (confirm('Mark this session as completed?')) {
                let schedules = this.loadUserData('userSchedules', []);
                const sessionIndex = schedules.findIndex(s => s.id === sessionId);
                if (sessionIndex !== -1) {
                    schedules[sessionIndex].status = 'completed';
                    this.saveUserData('userSchedules', schedules);
                    this.showMessage('Session marked as completed!', 'success');
                    // Reload page to refresh content
                    setTimeout(() => window.location.reload(), 1000);
                }
            }
        },

        // Leave group
        leaveGroup: function(groupId) {
            if (confirm('Are you sure you want to leave this group?')) {
                let groups = this.loadUserData('userGroups', []);
                groups = groups.filter(g => g.id !== groupId);
                this.saveUserData('userGroups', groups);
                this.showMessage('Left group successfully!', 'success');
                // Reload page to refresh content
                setTimeout(() => window.location.reload(), 1000);
            }
        }
    };

    // Initialize when DOM is loaded
    document.addEventListener('DOMContentLoaded', function() {
        StudyAuth.init();
    });

    // Global form handler for schedule creation
    window.handleScheduleSubmission = function(event) {
        event.preventDefault();

        if (!StudyAuth.isLoggedIn()) {
            StudyAuth.showMessage('Please login to create schedules.', 'danger');
            window.location.href = 'login.html';
            return;
        }

        // Get form data
        const formData = new FormData(event.target);
        const scheduleData = {
            id: Date.now(),
            subject: formData.get('subject'),
            topic: formData.get('topic'),
            date: formData.get('date'),
            time: formData.get('time'),
            duration: parseInt(formData.get('duration')),
            priority: formData.get('priority'),
            notes: formData.get('notes') || '',
            status: 'pending',
            createdAt: new Date().toISOString()
        };

        // Validate required fields
        if (!scheduleData.subject || !scheduleData.topic || !scheduleData.date ||
            !scheduleData.time || !scheduleData.duration || !scheduleData.priority) {
            StudyAuth.showMessage('Please fill in all required fields.', 'danger');
            return;
        }

        // Save schedule
        const existingSchedules = StudyAuth.loadUserData('userSchedules', []);
        existingSchedules.push(scheduleData);

        if (StudyAuth.saveUserData('userSchedules', existingSchedules)) {
            StudyAuth.showMessage('Schedule created successfully!', 'success');
            setTimeout(() => {
                window.location.href = 'schedules.html';
            }, 1500);
        } else {
            StudyAuth.showMessage('Failed to create schedule. Please try again.', 'danger');
        }
    };

})();
